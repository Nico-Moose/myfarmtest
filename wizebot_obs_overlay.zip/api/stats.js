export default async function handler(req, res) {
  const response = await fetch('https://wapi.wizebot.tv/api/user/currency/get', {
    headers: {
      'Authorization': 'Bearer 9ec7ac2ceb0dd0b8a740e852cb75fdb295225cbd83af5765e72eed77efe620b5'
    }
  });

  const viewersResponse = await fetch('https://wapi.wizebot.tv/api/user/viewers', {
    headers: {
      'Authorization': 'Bearer 9ec7ac2ceb0dd0b8a740e852cb75fdb295225cbd83af5765e72eed77efe620b5'
    }
  });

  if (!response.ok || !viewersResponse.ok) {
    return res.status(500).json({ error: 'Failed to fetch data' });
  }

  const data = await response.json();
  const viewerData = await viewersResponse.json();

  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    points: data.balance,
    sign: data.sign,
    viewers: viewerData.viewers
  });
}
